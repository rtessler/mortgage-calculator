------------------------------------------------------------
          README for Home Equity Loan Calculator
                  	Feb 9, 2009

         Copyright (C) 2007 Vertex42 LLC

http://www.vertex42.com/Calculators/home-equity-loan-calculator.html

Version: 1.2.0

------------------------
SYSTEM REQUIREMENTS
------------------------

This Excel spreadsheet should work with most versions of 
Microsoft Excel (with the exception of versions older than 
Excel 97). Some people have reported having trouble opening
these spreadsheets in Excel 2000.

------------------------
INSTALLING
------------------------

The Excel spreadsheet require no "installation".

After extracting the spreadsheet from the "zipped" file, 
just save it somewhere that you'll be able to find it again.

------------------------
TECHNICAL SUPPORT
------------------------

If you experience problems using the Home Equity Loan Calculator,
contact Vertex42 via email, and we will respond to your questions 
as soon as possible.

Visit the following page for contact information:
http://www.vertex42.com/about.html

------------------------
RELEASE NOTES
------------------------

Version 1.2.0 (Feb 9, 2009)
- Cosmetic changes
- Updated copyright notice / terms of use
Version 1.1.1 (Aug 4, 2007)
- Fixed Loan 2 Balance error in HomeEquity worksheet
Version 1.1.0 (Jul 12, 2007)
- Added the Home Equity Calculator worksheet
Version 1.0.0
- Initial Release

----------------------------
END USER LICENSE AGREEMENT
----------------------------

The software End User License Agreement (EULA_HomeEquityLoanCalculator.txt)
for this Excel spreadsheet is contained within the downloaded .zip file. 
It can also be found at:

http://www.vertex42.com/Files/eula/EULA_HomeEquityLoanCalculator.txt


___________________________________________________________________

Thank you for supporting Vertex42.com!

(C) 2007 Vertex42, LLC. All Rights Reserved.

Microsoft ane Microsoft Excel are registered trademarks of Microsoft Corporation. 
All other trademarks are the property of their respective holders.
